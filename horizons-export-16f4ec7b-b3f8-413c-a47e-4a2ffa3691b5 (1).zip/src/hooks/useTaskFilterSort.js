import React, { useState, useMemo } from 'react';

    const priorityOrder = { "Low": 1, "Medium": 2, "High": 3 };

    export function useTaskFilterSort(tasks) {
      const [filters, setFilters] = useState({
        searchTerm: '',
        category: 'All',
        priority: 'All',
        sortBy: 'default',
        status: 'all', // 'all', 'active', 'completed'
      });

      const handleFilterChange = (filterName, value) => {
        setFilters(prev => ({ ...prev, [filterName]: value }));
      };

      const filteredAndSortedTasks = useMemo(() => {
        let result = [...tasks];

        if (filters.status === 'active') {
          result = result.filter(task => !task.completed);
        } else if (filters.status === 'completed') {
          result = result.filter(task => task.completed);
        }

        if (filters.searchTerm) {
          result = result.filter(task =>
            task.title.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
            (task.description && task.description.toLowerCase().includes(filters.searchTerm.toLowerCase()))
          );
        }
        if (filters.category !== 'All') {
          result = result.filter(task => task.category === filters.category);
        }
        if (filters.priority !== 'All') {
          result = result.filter(task => task.priority === filters.priority);
        }

        switch (filters.sortBy) {
          case 'dueDateAsc':
            result.sort((a, b) => (a.dueDate && b.dueDate) ? new Date(a.dueDate) - new Date(b.dueDate) : a.dueDate ? -1 : b.dueDate ? 1 : 0);
            break;
          case 'dueDateDesc':
            result.sort((a, b) => (a.dueDate && b.dueDate) ? new Date(b.dueDate) - new Date(a.dueDate) : a.dueDate ? 1 : b.dueDate ? -1 : 0);
            break;
          case 'priorityAsc':
            result.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
            break;
          case 'priorityDesc':
            result.sort((a, b) => priorityOrder[b.priority] - priorityOrder[a.priority]);
            break;
          case 'titleAsc':
            result.sort((a, b) => a.title.localeCompare(b.title));
            break;
          case 'titleDesc':
            result.sort((a, b) => b.title.localeCompare(a.title));
            break;
          case 'completedAtDesc':
            result.sort((a,b) => (a.completedAt && b.completedAt) ? new Date(b.completedAt) - new Date(a.completedAt) : a.completedAt ? -1 : b.completedAt ? 1 : 0);
            break;
          case 'default':
          default:
             result.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
            break;
        }
        return result;
      }, [tasks, filters]);

      return {
        filters,
        handleFilterChange,
        filteredAndSortedTasks,
      };
    }