import React, { useState, useEffect } from 'react';
    import useLocalStorage from '@/hooks/useLocalStorage';
    import { useToast } from '@/components/ui/use-toast';

    export function useTaskManager(initialTasks = []) {
      const [tasks, setTasks] = useLocalStorage('tasks', initialTasks);
      const [taskToEdit, setTaskToEdit] = useState(null);
      const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
      const [taskToDeleteId, setTaskToDeleteId] = useState(null);
      const { toast } = useToast();

      const handleSaveTask = (taskData) => {
        if (taskToEdit) {
          setTasks(prevTasks => prevTasks.map(task => task.id === taskData.id ? taskData : task));
          toast({
            title: "Task Updated",
            description: `Task "${taskData.title}" updated successfully.`,
            className: 'bg-green-500 text-white',
          });
        } else {
          setTasks(prevTasks => [taskData, ...prevTasks]);
          toast({
            title: "Task Added",
            description: `Task "${taskData.title}" added successfully.`,
            className: 'bg-green-500 text-white',
          });
        }
        setTaskToEdit(null);
      };

      const handleEditTask = (task) => {
        setTaskToEdit(task);
      };

      const handleDeleteTask = (id) => {
        setTaskToDeleteId(id);
        setShowDeleteConfirm(true);
      };

      const confirmDeleteTask = () => {
        setTasks(prevTasks => prevTasks.filter(task => task.id !== taskToDeleteId));
        toast({
          title: "Task Deleted",
          description: "The task has been successfully deleted.",
          variant: "destructive",
        });
        setShowDeleteConfirm(false);
        setTaskToDeleteId(null);
      };

      const handleToggleComplete = (id) => {
        setTasks(prevTasks => prevTasks.map(task =>
          task.id === id ? { ...task, completed: !task.completed, completedAt: !task.completed ? new Date().toISOString() : null } : task
        ));
      };
      
      useEffect(() => {
        tasks.forEach(task => {
          if (task.dueDate && !task.completed) {
            const today = new Date();
            today.setHours(0,0,0,0);
            const dueDate = new Date(task.dueDate);
            dueDate.setHours(0,0,0,0);
            const timeDiff = dueDate.getTime() - today.getTime();
            const daysRemaining = Math.ceil(timeDiff / (1000 * 3600 * 24));

            if (daysRemaining === 0) {
              toast({
                title: "Reminder: Task Due Today!",
                description: `Your task "${task.title}" is due today.`,
                variant: "default",
                duration: 7000,
              });
            } else if (daysRemaining === 1) {
               toast({
                title: "Reminder: Task Due Tomorrow!",
                description: `Your task "${task.title}" is due tomorrow.`,
                variant: "default",
                duration: 7000,
              });
            }
          }
          if ((task.category === "Groceries" || task.category === "Shopping") && task.budget && !task.completed) {
             if (Math.random() < 0.1) { 
                toast({
                    title: "Budget Reminder",
                    description: `Remember your budget for "${task.title}": ${task.budget.toFixed(2)}.`,
                    variant: "default",
                    duration: 7000,
                });
             }
          }
        });
      }, [tasks, toast]);


      return {
        tasks,
        taskToEdit,
        setTaskToEdit,
        showDeleteConfirm,
        setShowDeleteConfirm,
        taskToDeleteId,
        handleSaveTask,
        handleEditTask,
        handleDeleteTask,
        confirmDeleteTask,
        handleToggleComplete,
      };
    }