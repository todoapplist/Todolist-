import React, { useState, useMemo } from 'react';
    import { motion } from 'framer-motion';
    import { ThemeProvider, useTheme } from '@/contexts/ThemeContext';
    import { Toaster } from '@/components/ui/toaster';
    import { TaskForm } from '@/components/TaskForm';
    import { FilterControls } from '@/components/FilterControls';
    import { CheckCircle2, History, ListTodo } from 'lucide-react';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from '@/components/ui/alert-dialog';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
    import { useTaskManager } from '@/hooks/useTaskManager';
    import { useTaskFilterSort } from '@/hooks/useTaskFilterSort';
    import { TaskList } from '@/components/TaskList';
    import { AppHeader } from '@/components/AppHeader';
    import { AppFooter } from '@/components/AppFooter';

    const AppContent = () => {
      const { theme } = useTheme();
      const {
        tasks,
        taskToEdit,
        setTaskToEdit,
        showDeleteConfirm,
        setShowDeleteConfirm,
        taskToDeleteId,
        handleSaveTask,
        handleEditTask,
        handleDeleteTask,
        confirmDeleteTask,
        handleToggleComplete,
      } = useTaskManager();

      const {
        filters,
        handleFilterChange,
        filteredAndSortedTasks,
      } = useTaskFilterSort(tasks);

      const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
      const [activeTab, setActiveTab] = useState("active");

      const openAddNewTaskForm = (isEditing = false) => {
        if(!isEditing) setTaskToEdit(null);
        setIsTaskFormOpen(true);
      };
      
      const onEditTaskWrapper = (task) => {
        handleEditTask(task);
        setIsTaskFormOpen(true);
      };
      
      const tasksToDisplay = useMemo(() => {
        if (activeTab === 'active') {
          return filteredAndSortedTasks.filter(task => !task.completed);
        } else {
          const completed = filteredAndSortedTasks.filter(task => task.completed);
          if (filters.sortBy === 'default' || !filters.sortBy) { // Sort by completed date if default
             return completed.sort((a,b) => (a.completedAt && b.completedAt) ? new Date(b.completedAt) - new Date(a.completedAt) : a.completedAt ? -1 : b.completedAt ? 1 : 0);
          }
          return completed;
        }
      }, [filteredAndSortedTasks, activeTab, filters.sortBy]);

      const totalTasksCount = tasks.length;
      const activeTasksCount = tasks.filter(task => !task.completed).length;
      const completedTasksCount = totalTasksCount - activeTasksCount;
      
      const progressPercentage = totalTasksCount > 0 ? (completedTasksCount / totalTasksCount) * 100 : 0;

      return (
        <div className={`min-h-screen flex flex-col transition-colors duration-300 ${theme === 'dark' ? 'bg-gradient-to-br from-gray-900 to-gray-800' : 'bg-gradient-to-br from-slate-100 to-sky-100'}`}>
          <AppHeader onAddNewTask={() => openAddNewTaskForm(false)} />

          <main className="flex-grow container py-8 px-4 md:px-6">
            <TaskForm
              open={isTaskFormOpen}
              onOpenChange={setIsTaskFormOpen}
              onSave={handleSaveTask}
              taskToEdit={taskToEdit}
            />

            <FilterControls filters={filters} onFilterChange={handleFilterChange} />
            
            {totalTasksCount > 0 && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 text-lg text-center text-muted-foreground"
              >
                <div className="flex items-center justify-center mb-2">
                    <CheckCircle2 className="inline-block mr-2 h-5 w-5 text-green-500" />
                    <span>{completedTasksCount} of {totalTasksCount} tasks completed.</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2.5 dark:bg-gray-700">
                    <div className="bg-gradient-to-r from-primary to-accent h-2.5 rounded-full transition-all duration-500 ease-out" style={{ width: `${progressPercentage}%` }}></div>
                </div>
              </motion.div>
            )}

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2 md:w-1/2 mx-auto">
                <TabsTrigger value="active" className="flex items-center gap-2">
                  <ListTodo size={18}/> Active Tasks ({activeTasksCount})
                </TabsTrigger>
                <TabsTrigger value="completed" className="flex items-center gap-2">
                  <History size={18}/> History ({completedTasksCount})
                </TabsTrigger>
              </TabsList>
              <TabsContent value="active">
                <TaskList
                  tasks={tasksToDisplay}
                  onToggleComplete={handleToggleComplete}
                  onEdit={onEditTaskWrapper}
                  onDelete={handleDeleteTask}
                  openAddNewTaskForm={() => openAddNewTaskForm(false)}
                  currentFilterStatus="active"
                  filters={filters}
                />
              </TabsContent>
              <TabsContent value="completed">
                 <TaskList
                  tasks={tasksToDisplay}
                  onToggleComplete={handleToggleComplete}
                  onEdit={onEditTaskWrapper}
                  onDelete={handleDeleteTask}
                  openAddNewTaskForm={() => openAddNewTaskForm(false)}
                  currentFilterStatus="completed"
                  filters={filters}
                />
              </TabsContent>
            </Tabs>
          </main>

          <AppFooter />

          <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the task.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setShowDeleteConfirm(false)}>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDeleteTask} className="bg-destructive hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Toaster />
        </div>
      );
    };

    function App() {
      return (
        <ThemeProvider>
          <AppContent />
        </ThemeProvider>
      );
    }

    export default App;