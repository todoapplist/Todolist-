
    import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Badge } from '@/components/ui/badge';
    import { Edit2, Trash2, CalendarDays, DollarSign, AlertTriangle } from 'lucide-react';
    import {
      Tooltip,
      TooltipContent,
      TooltipProvider,
      TooltipTrigger,
    } from '@/components/ui/tooltip';

    export function TaskItem({ task, onToggleComplete, onEdit, onDelete }) {
      const priorityColors = {
        Low: 'info',
        Medium: 'warning',
        High: 'destructive',
      };

      const categoryColors = {
        Personal: 'bg-blue-500',
        Work: 'bg-purple-500',
        Groceries: 'bg-green-500',
        Shopping: 'bg-pink-500',
        Urgent: 'bg-red-600',
        Other: 'bg-gray-500',
      }

      const getDaysRemaining = (dueDate) => {
        if (!dueDate) return null;
        const today = new Date();
        today.setHours(0,0,0,0);
        const due = new Date(dueDate);
        due.setHours(0,0,0,0); // Compare dates only
        const diffTime = due - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
      };

      const daysRemaining = getDaysRemaining(task.dueDate);
      const isOverdue = daysRemaining !== null && daysRemaining < 0;
      const isDueSoon = daysRemaining !== null && daysRemaining >= 0 && daysRemaining <= 2;


      return (
        <TooltipProvider delayDuration={100}>
          <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="mb-4"
          >
            <Card className={`transition-all duration-300 ease-in-out hover:shadow-xl ${task.completed ? 'bg-muted/50 opacity-70' : 'bg-card'}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.completed}
                      onCheckedChange={() => onToggleComplete(task.id)}
                      aria-label={task.completed ? "Mark task as incomplete" : "Mark task as complete"}
                    />
                    <CardTitle className={`text-xl font-semibold ${task.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                      {task.title}
                    </CardTitle>
                  </div>
                  <Badge variant={priorityColors[task.priority]} className="text-xs">{task.priority}</Badge>
                </div>
              </CardHeader>
              <CardContent className="pb-4 space-y-2">
                {task.description && (
                  <p className={`text-sm ${task.completed ? 'text-muted-foreground' : 'text-foreground/80'}`}>{task.description}</p>
                )}
                <div className="flex flex-wrap gap-2 items-center text-xs">
                  <Badge className={`${categoryColors[task.category] || 'bg-gray-500'} text-white`}>{task.category}</Badge>
                  {task.dueDate && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge variant="outline" className={`flex items-center gap-1 ${isOverdue ? 'border-red-500 text-red-500' : isDueSoon ? 'border-yellow-500 text-yellow-500' : ''}`}>
                          <CalendarDays size={14} />
                          {new Date(task.dueDate).toLocaleDateString()}
                          {isOverdue && <AlertTriangle size={14} className="ml-1" />}
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>
                          {isOverdue ? `Overdue by ${Math.abs(daysRemaining)} day(s)` : 
                           daysRemaining === 0 ? 'Due today' :
                           daysRemaining === 1 ? 'Due tomorrow' :
                           `Due in ${daysRemaining} day(s)`}
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  )}
                  {task.budget && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge variant="outline" className="flex items-center gap-1">
                          <DollarSign size={14} />
                          {task.budget.toFixed(2)}
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Budget: ${task.budget.toFixed(2)}</p>
                      </TooltipContent>
                    </Tooltip>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end space-x-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => onEdit(task)} aria-label="Edit task">
                      <Edit2 className="h-4 w-4 text-blue-500" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent><p>Edit Task</p></TooltipContent>
                </Tooltip>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(task.id)} aria-label="Delete task">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent><p>Delete Task</p></TooltipContent>
                </Tooltip>
              </CardFooter>
            </Card>
          </motion.div>
        </TooltipProvider>
      );
    }
  