
    import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogFooter,
      DialogClose,
    } from '@/components/ui/dialog';
    import {
      Select,
      SelectContent,
      SelectItem,
      SelectTrigger,
      SelectValue,
    } from '@/components/ui/select';
    import { useToast } from '@/components/ui/use-toast';
    import { PlusCircle, Edit } from 'lucide-react';

    const categories = ["Personal", "Work", "Groceries", "Shopping", "Urgent", "Other"];
    const priorities = ["Low", "Medium", "High"];

    export function TaskForm({ open, onOpenChange, onSave, taskToEdit }) {
      const [title, setTitle] = useState('');
      const [description, setDescription] = useState('');
      const [category, setCategory] = useState(categories[0]);
      const [priority, setPriority] = useState(priorities[1]);
      const [dueDate, setDueDate] = useState('');
      const [budget, setBudget] = useState('');
      const { toast } = useToast();

      useEffect(() => {
        if (taskToEdit) {
          setTitle(taskToEdit.title);
          setDescription(taskToEdit.description || '');
          setCategory(taskToEdit.category || categories[0]);
          setPriority(taskToEdit.priority || priorities[1]);
          setDueDate(taskToEdit.dueDate || '');
          setBudget(taskToEdit.budget || '');
        } else {
          setTitle('');
          setDescription('');
          setCategory(categories[0]);
          setPriority(priorities[1]);
          setDueDate('');
          setBudget('');
        }
      }, [taskToEdit, open]);

      const handleSubmit = (e) => {
        e.preventDefault();
        if (!title.trim()) {
          toast({
            title: "Error",
            description: "Task title cannot be empty.",
            variant: "destructive",
          });
          return;
        }

        const taskData = {
          id: taskToEdit ? taskToEdit.id : Date.now().toString(),
          title: title.trim(),
          description: description.trim(),
          category,
          priority,
          dueDate,
          budget: budget ? parseFloat(budget) : null,
          completed: taskToEdit ? taskToEdit.completed : false,
          createdAt: taskToEdit ? taskToEdit.createdAt : new Date().toISOString(),
        };
        onSave(taskData);
        onOpenChange(false);
        toast({
          title: "Success!",
          description: `Task ${taskToEdit ? 'updated' : 'added'} successfully.`,
          className: 'bg-green-500 text-white',
        });
      };
      
      const today = new Date().toISOString().split('T')[0];

      return (
        <Dialog open={open} onOpenChange={onOpenChange}>
          <DialogContent className="sm:max-w-[425px] bg-card">
            <DialogHeader>
              <DialogTitle className="text-2xl gradient-text">
                {taskToEdit ? 'Edit Task' : 'Add New Task'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="grid gap-6 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title" className="text-left">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Buy groceries"
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description" className="text-left">Description (Optional)</Label>
                <Input
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g., Milk, eggs, bread"
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="category" className="text-left">Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="priority" className="text-left">Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map((prio) => (
                        <SelectItem key={prio} value={prio}>{prio}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="dueDate" className="text-left">Due Date (Optional)</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="col-span-3"
                    min={today}
                  />
                </div>
                {(category === "Groceries" || category === "Shopping") && (
                  <div className="grid gap-2">
                    <Label htmlFor="budget" className="text-left">Budget (Optional)</Label>
                    <Input
                      id="budget"
                      type="number"
                      value={budget}
                      onChange={(e) => setBudget(e.target.value)}
                      placeholder="e.g., 50"
                      className="col-span-3"
                      min="0"
                      step="0.01"
                    />
                  </div>
                )}
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="outline">Cancel</Button>
                </DialogClose>
                <Button type="submit" className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity">
                  {taskToEdit ? 'Save Changes' : 'Add Task'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    }
  