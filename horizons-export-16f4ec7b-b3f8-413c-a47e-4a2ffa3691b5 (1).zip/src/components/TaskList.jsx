import React from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { TaskItem } from '@/components/TaskItem';
    import { AlertOctagon, PlusCircle } from 'lucide-react';
    import { Button } from '@/components/ui/button';

    export function TaskList({ tasks, onToggleComplete, onEdit, onDelete, openAddNewTaskForm, currentFilterStatus, filters }) {
      if (tasks.length === 0) {
        let emptyMessage = "Looks like your to-do list is empty. Add a new task to get started!";
        let showFilterMessage = false;
        if (currentFilterStatus === 'active' && (filters.searchTerm || filters.category !== 'All' || filters.priority !== 'All')) {
            emptyMessage = "No active tasks match your current filters. Try adjusting them or check your completed tasks!";
            showFilterMessage = true;
        } else if (currentFilterStatus === 'active') {
            emptyMessage = "All tasks are completed! Add a new task or take a break!";
        } else if (currentFilterStatus === 'completed' && (filters.searchTerm || filters.category !== 'All' || filters.priority !== 'All')) {
            emptyMessage = "No completed tasks match your current filters. Try adjusting them or check your active tasks!";
            showFilterMessage = true;
        } else if (currentFilterStatus === 'completed') {
            emptyMessage = "No tasks completed yet. Keep working on them!";
        }


        return (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-16"
          >
            <AlertOctagon className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h2 className="text-2xl font-semibold text-foreground mb-2">
              {currentFilterStatus === 'active' ? "No Active Tasks" : "No Completed Tasks"}
            </h2>
            <p className="text-muted-foreground mb-6">{emptyMessage}</p>
            {currentFilterStatus === 'active' && !showFilterMessage && (
              <Button onClick={openAddNewTaskForm} size="lg" className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-lg">
                <PlusCircle className="mr-2 h-5 w-5" /> Add Task
              </Button>
            )}
          </motion.div>
        );
      }

      return (
        <AnimatePresence>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {tasks.map(task => (
              <TaskItem
                key={task.id}
                task={task}
                onToggleComplete={onToggleComplete}
                onEdit={task => { onEdit(task); openAddNewTaskForm(true); }}
                onDelete={onDelete}
              />
            ))}
          </div>
        </AnimatePresence>
      );
    }