import React from 'react';
    import { Button } from '@/components/ui/button';
    import { ThemeToggle } from '@/components/ThemeToggle';
    import { PlusCircle, ListChecks } from 'lucide-react';

    export function AppHeader({ onAddNewTask }) {
      return (
        <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <div className="flex items-center">
              <ListChecks className="h-8 w-8 mr-3 gradient-text" />
              <h1 className="text-3xl font-bold tracking-tight gradient-text">Todo List</h1>
            </div>
            <div className="flex items-center space-x-2">
              <ThemeToggle />
              <Button onClick={onAddNewTask} className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-lg">
                <PlusCircle className="mr-2 h-5 w-5" /> Add Task
              </Button>
            </div>
          </div>
        </header>
      );
    }