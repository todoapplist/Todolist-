
    import React from 'react';
    import { Input } from '@/components/ui/input';
    import {
      Select,
      SelectContent,
      SelectItem,
      SelectTrigger,
      SelectValue,
    } from '@/components/ui/select';
    import { Search, ListFilter, ArrowDownUp, AlertTriangle } from 'lucide-react';

    const categories = ["All", "Personal", "Work", "Groceries", "Shopping", "Urgent", "Other"];
    const priorities = ["All", "Low", "Medium", "High"];
    const sortOptions = [
      { value: "default", label: "Default" },
      { value: "dueDateAsc", label: "Due Date (Oldest)" },
      { value: "dueDateDesc", label: "Due Date (Newest)" },
      { value: "priorityAsc", label: "Priority (Low to High)" },
      { value: "priorityDesc", label: "Priority (High to Low)" },
      { value: "titleAsc", label: "Title (A-Z)" },
      { value: "titleDesc", label: "Title (Z-A)" },
    ];


    export function FilterControls({ filters, onFilterChange }) {
      return (
        <div className="mb-6 p-4 bg-card rounded-lg shadow-md">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search tasks..."
                value={filters.searchTerm}
                onChange={(e) => onFilterChange('searchTerm', e.target.value)}
                className="pl-10"
                aria-label="Search tasks"
              />
            </div>
            
            <div>
              <Select value={filters.category} onValueChange={(value) => onFilterChange('category', value)}>
                <SelectTrigger aria-label="Filter by category">
                  <ListFilter className="h-4 w-4 mr-2 text-muted-foreground" />
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={filters.priority} onValueChange={(value) => onFilterChange('priority', value)}>
                <SelectTrigger aria-label="Filter by priority">
                  <AlertTriangle className="h-4 w-4 mr-2 text-muted-foreground" />
                  <SelectValue placeholder="Filter by priority" />
                </SelectTrigger>
                <SelectContent>
                  {priorities.map(prio => (
                    <SelectItem key={prio} value={prio}>{prio}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="md:col-span-2 lg:col-span-1">
               <Select value={filters.sortBy} onValueChange={(value) => onFilterChange('sortBy', value)}>
                <SelectTrigger aria-label="Sort by">
                  <ArrowDownUp className="h-4 w-4 mr-2 text-muted-foreground" />
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      );
    }
  